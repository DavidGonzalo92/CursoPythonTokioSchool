package org.com.tokioschool;
import java.util.Scanner;


public class valdiar_contrase�a {

	public static void main(String[] args) {
		String contrase�ausuario, contrase�avalidar;
	    int contador=3,intentos;
	    Scanner teclado= new Scanner(System.in);
	      
	   
	    System.out.println("introduca la contrase�a:");
	    contrase�ausuario=teclado.nextLine();
	      
	    for(int x = 1; x<=contador ;x++){ 
	    intentos=contador+1-x;
	    System.out.println("introduca la contrase�a para validar tiene "+ intentos +" intentos");
	    contrase�avalidar=teclado.nextLine();
	          if(contrase�ausuario.equals(contrase�avalidar)) {
	        	  System.out.println("bienvenido");
	        	 break;
	        	  
	        	  
	          }
	          if(x==contador) {
	        	  System.out.println("cuenta bloqueada");

	        	  
	        	  
	          }
	    }
	      

	    }
	}
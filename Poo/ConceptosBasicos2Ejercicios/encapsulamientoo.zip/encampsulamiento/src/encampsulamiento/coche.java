package encampsulamiento;




public class coche extends vehiculo{
	private String color;
	int velocidad;

	
	
	
	public coche(String color) {                         
	this.color=color;
	
  
	}
	
	
	
	public String marcacoche(){
        return "marca is " + marca; 
    }


	public void setcolor(String s) {
		color=s;
	}

	public String getcolor() {
		return color;
	}





}

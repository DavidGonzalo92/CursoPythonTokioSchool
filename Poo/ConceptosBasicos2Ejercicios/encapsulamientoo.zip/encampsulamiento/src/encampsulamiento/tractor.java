package encampsulamiento;

public class tractor extends vehiculo {
	private String color;
	int velocidad;

	
	
	
	public tractor(String color) {                         
	this.color=color;
	
  
	}
	
	
	
	public String marcatractor(){
        return "marca is " + marca; 
    }


	public void setcolor(String s) {
		color=s;
	}

	public String getcolor() {
		return color;
	}

	
}

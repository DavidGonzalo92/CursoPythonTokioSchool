package encampsulamiento;

public class ejecutor {

	public static void main(String[] args) {

		coche focus= new  coche("verde"); 
		focus.velocidad=15;
		
		moto harley= new  moto("verde"); 
		harley.velocidad=40;

		
		tractor Fendt= new  tractor("verde"); 
		Fendt.velocidad=30;

		System.out.print(" publico: " + focus.velocidad + "\n protected : "+ focus.marcacoche() +"\n privated : " + focus.getcolor() +"\n");
		System.out.print(" publico: " + harley.velocidad + "\n protected : "+ harley.marcamoto() +"\n privated : " + harley.getcolor()+"\n" );
		System.out.print(" publico: " + Fendt.velocidad + "\n protected : "+ Fendt.marcatractor() +"\n privated : " + Fendt.getcolor()+"\n" );
	}

}

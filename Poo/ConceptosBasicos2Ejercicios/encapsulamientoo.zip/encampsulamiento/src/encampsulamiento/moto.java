package encampsulamiento;

public class moto extends vehiculo {
	private String color;
	int velocidad;

	
	
	
	public moto(String color) {                         
	this.color=color;
	
  
	}
	
	
	
	public String marcamoto(){
        return "marca is " + marca; 
    }


	public void setcolor(String s) {
		color=s;
	}

	public String getcolor() {
		return color;
	}

}

package encampsulamiento;

public class vehiculo {
	protected String marca = "renault";
	
	
}


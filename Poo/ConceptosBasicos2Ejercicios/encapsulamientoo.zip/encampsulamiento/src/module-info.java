module encampsulamiento {
}
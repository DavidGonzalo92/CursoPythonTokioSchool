package polimorfismo;

public class polimorfismoanimal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		   Animal a = new gato();    
		   Animal b = new cerdo();  
		   Animal c = new perro();  
		      a.comida();               
		      b.comida();
		      c.comida();

	}

}

package polimorfismo;

abstract class Animal {  
    abstract void comida();  
    abstract void trabajo(); 
    abstract void maullido(); 
}  
  





class gato extends Animal {  
  public void comida() {  
      System.out.println("Come pescado");  
  }  
  public void trabajo() {  
      System.out.println("Atrapa el rat�n");  
  }
  
  public void maullido() {  
      System.out.println("miau");  
  }



}  

class perro extends Animal {  
  public void comida() {  
      System.out.println("Come huesos");  
  }  
  public void trabajo() {  
      System.out.println("Limpieza interna");  
  }

  public void maullido() {  
      System.out.println("guau");  
  }
}
  
  
  
  
class cerdo extends Animal {  
	  public void comida() {  
	      System.out.println("cualquier cosa");  
	  }  
	  public void trabajo() {  
	      System.out.println("dar carne");  
	  }

	  public void maullido() {  
	      System.out.println("oing");  
	  }
	}
  
  
class delfin extends Animal {

	@Override
	void comida() {
		// TODO Auto-generated method stub
		
	}

	@Override
	void trabajo() {
		// TODO Auto-generated method stub
		
	}

	@Override
	void maullido() {
		// TODO Auto-generated method stub
		
	}  

	} 
  
  
class tiranosaurio extends Animal {

	@Override
	void comida() {
		// TODO Auto-generated method stub
		
	}

	@Override
	void trabajo() {
		// TODO Auto-generated method stub
		
	}

	@Override
	void maullido() {
		// TODO Auto-generated method stub
		
	}}





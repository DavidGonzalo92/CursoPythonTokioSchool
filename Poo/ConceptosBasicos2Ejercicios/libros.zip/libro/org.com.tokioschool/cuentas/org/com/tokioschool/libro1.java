package org.com.tokioschool;

public class libro1 {
	private String isbn;
    private String titulo;
    private String autor;
    private int pagina;
    
    
   





    public libro1(String isbn, String titulo,String autor,int pagina) {                         
        this.isbn = isbn;
        this.titulo = titulo;
        this.autor = autor;
        this.pagina = pagina;
        
        

    }


    
    
    public libro1(final libro1 c) {
    	isbn = c.isbn;
    	titulo = c.titulo;
    	autor = c.autor;
    	pagina = c.pagina;
    }

    //getters y setters
    public void setisbn(String s) {
    	isbn = s;
    }

    public void settitulo(String s) {
    	titulo = s;
    }
    
    public void setautor(String s) {
    	autor = s;
    }
    public void setpagina(int n) {
    	pagina = n;
    }


    public String getisbn() {
        return isbn;
    }

    public String gettitulo() {
        return titulo;
    }
    
    
    public String getautor() {
        return autor;
    }
    
    public int getpagina() {
        return pagina;
    }

    



    public static void Compararlibro(libro1 c,libro1 s)
    {
    	 if(c.getpagina()>s.getpagina()) {
			 System.out.print("libro 1 es mayor que libro 2");
		 }
		 if(c.getpagina()==s.getpagina()) {
			 System.out.print("libro iguales");
		 }
		 if(c.getpagina()<s.getpagina()) {
			 System.out.print("libro 2 es mayor que libro 1");
		 }

    }
    
    
    @Override
   	public String toString() {
    	
        
        return "el libro " + titulo + " con el isbn" + isbn +" y autor " + autor +" tiene  " + pagina +" paginas.\n";
        
       }
    

	}

	

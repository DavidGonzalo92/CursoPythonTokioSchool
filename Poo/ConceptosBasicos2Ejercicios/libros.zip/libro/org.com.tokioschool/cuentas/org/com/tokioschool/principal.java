package org.com.tokioschool;
import java.util.Scanner;


public class principal {

	public static void main(String[] args) {
			
		
		libro1 a=new libro1("bsfbssbbsbsb1","ciencia de datos","david",100);
		
		
		System.out.print(a.toString());
		
		libro1 b=new libro1("ffwrfwef1","ciencia de datos2","david",100);
			

		System.out.print(b.toString() );
		
		libro1.Compararlibro(a, b);


	   }
}
package clases;

public class ejecutor {



	public static void main(String[] args) {
		
		
		System.out.print("area es "+cuadrado.area(2,2)+" perimetro es "+cuadrado.perimetro(2, 2) );

	}

}

package clases;

public class cuadrado {
	
	
		protected final static  int Lado1=2;
		private final static int   Lado2=2;
		
		public static double area(int lado1,int lado2) {

			 return lado1*lado2;
			 }
			 
		public static double perimetro(int lado1,int lado2) {
			 
			 return lado1*2+lado2*2;
			 }
		
		private  double areaprivada(int lado1,int lado2) {
			 
			 return lado1*lado1;
			 }
}

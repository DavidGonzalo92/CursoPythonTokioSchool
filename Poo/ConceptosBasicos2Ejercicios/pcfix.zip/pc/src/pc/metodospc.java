package pc;

public class metodospc {
	

	private String marca;
    private String modelo;
    private int RAM;
    private int HD;
    
    
   





    public metodospc(String marca, String modelo, int RAM, int HD) {                         
        this.marca = marca;
        this.modelo = modelo;
        this.RAM = RAM;
        this.HD = HD;
        
        

    }
    
    
    
    
    
    
    public void setmarca(String s) {
    	marca = s;
    }

    public void setmodelo(String s) {
    	modelo = s;
    }
    
    public void setRAM(int n) {
    	RAM = n;
    }
    public void setHD(int n) {
    	HD = n;
    }


    public String getmarca() {
        return marca;
    }
    public String getmodelo() {
        return modelo;
    }
    public int getRAM() {
        return RAM;
    }
    public int getHD() {
        return HD;
    }
    
    
    @Override
    public String toString() {
        return marca + ", " + modelo + ", " + RAM+", "+HD;
    } 

}

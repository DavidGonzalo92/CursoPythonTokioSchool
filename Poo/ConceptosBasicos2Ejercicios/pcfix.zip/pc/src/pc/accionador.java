package pc;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class accionador {

	public static void main(String[] args) {
		
		
		
		Scanner sc = new Scanner(System.in);
		String marca, modelo,clave,palabraclave="si";
		int RAM,HD;
		List<metodospc> listaordenadores = new ArrayList<>();
		
		
		

		do
		{
			
			System.out.print("dame la marca que quieres a�adir: ");
			
			marca=sc.nextLine();
			
			System.out.print("dame el modelo :");
			
			modelo=sc.nextLine();
			
			System.out.print("dame RAM de el : ");
			
			RAM=sc.nextInt();
			
			System.out.print("dame el HD de el : ");
			
			HD=sc.nextInt();
			
			
			
			
			metodospc b = new metodospc(marca, modelo,RAM, HD);
			
			listaordenadores.add(b);
			
			
			
			System.out.print("quieres introducir mas modelos si es si pon un si, si es no pon la palabra que quieras : ");
			

			sc.nextLine();
			
			
			palabraclave=sc.nextLine();
			


		} while(palabraclave.equals("si"));
		
		
		System.out.print("los modelos en la base de datos son estos : \n");		


	    for (metodospc a : listaordenadores) {
	        System.out.println(a.toString());
	    }

	}

}

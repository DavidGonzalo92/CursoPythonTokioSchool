package naturaleza;

public class planta implements naturaleza{
	
	public void tipo(){
		System.out.println("");
		
	}
	
	
	public void eat() {  
        System.out.println("");  
    }  
	
}

package naturaleza;

public class ejecutor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		gato gato = new gato();//clase gato tienes la herencia y la llamada a la clase principal
		
		gato.correrTest();
		
	}

}

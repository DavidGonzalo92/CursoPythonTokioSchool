package naturaleza;

public interface naturaleza {

	public void tipo();
	
	
    

	}





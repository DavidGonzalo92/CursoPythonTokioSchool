package naturaleza;
//Herencia de gato
public class gato extends animal {
	
	public void correr(){
		System.out.println("gato esta corriendo");
	}
	void correrTest(){
		super.correr(); //super: uso la palabra clave super para acceder a los miembros de la clase principal actual para aplicar la clase principal del objeto actual

		this.correr();
	}

}

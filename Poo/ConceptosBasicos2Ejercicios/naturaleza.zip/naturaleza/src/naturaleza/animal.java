package naturaleza;

public class animal implements naturaleza{
	public void tipo(){
		System.out.println("");
		
	}

	
    public void correr() {  
        System.out.println("animal esta en movimiento");  
    }  
}

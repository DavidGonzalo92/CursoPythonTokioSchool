package primo;

import java.util.Scanner;

public class primo {
	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	int numero, contador=2;
	boolean primos=true;

	 
	System.out.print("dame un numero mayor que 0 y menor que 100: \n");

	numero=sc.nextInt();
	
	while(numero<=0 || numero>=100) {
		System.out.print("el numero introducido es erronio, dame un numero mayor que 0 y menor que 100 \n");
		numero=sc.nextInt();
	}
	
	
	if (numero==1){
		System.out.print(numero +"  es primo ");
	}
	else {
	while(primos==true && contador!=numero) {
		
	
		if (numero % contador == 0) {
			System.out.print(numero +" no es primo ");
			primos = false;
		}
		else if(numero==contador+1) {
			System.out.print(numero +" es primo");
			
		}
		
	   contador++;
	  }
	}
	
	
	 }
}
	
	

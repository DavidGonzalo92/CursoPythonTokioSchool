package tabla9;

import java.util.Scanner;

public class tabla9 {
	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	int incremento = 9,numero,resultado;

	 
	System.out.print("dime que tabla quieres");

	numero=sc.nextInt();
	
	while ( incremento!=0) {
		  resultado=numero*incremento;
		  System.out.print(incremento +"x" +numero+"="+resultado+"\n");
		  incremento--;
		}

	}
}

package notadel0a10;

import java.util.Scanner;

public class notadel0a10 {
	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	double numero;

	 
	System.out.print("dame una nota del 0 a 10 \n");
	
	numero=sc.nextDouble();
	
	while(numero<0 || numero>10) {
		System.out.print("el numero introducido es erronio, dame una nota del 0 a 10 \n");
		numero=sc.nextDouble();
	}
	
	if(numero>=0 && numero<5) {
		System.out.print("insuficiente");
	}
	else if(numero>=5 && numero<6) {
		System.out.print("suficiente");
	 }
	else if(numero>=6 && numero<7) {
		System.out.print("bien");
	 }
	else if(numero>=7 && numero<9) {
		System.out.print("notable");
	 }
	else {
		System.out.print("sobresaliente");
	}
	
	}
}
	
	

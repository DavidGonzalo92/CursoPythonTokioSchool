package area;

import java.util.Scanner;

public class areacuadrado {
	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	double a, b;
	 
	 
	System.out.print("introduce el lado del cuadrado");
	a=sc.nextDouble();
	b=a*a;
	System.out.print("el area del cuandrado es : "+b);
	}
}

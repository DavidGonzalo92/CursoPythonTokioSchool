package arreglofactorial;



import java.util.Scanner;

public class arreglofact {
	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	double  factorial = 1,numero,numero2;

	 
	System.out.print("dame un numero entre 0 y 10 para sacar el factorial");

	numero=sc.nextDouble();
	
	while(numero>10 || numero<0) {
		System.out.print("dame un numero entre 0 y 10");

		numero=sc.nextDouble();
		
	}
    	
	numero2=numero;
	
	if (numero2==0) {
		System.out.print("el factorial de " + numero + " es 1");
	}
	else {
	while ( numero2!=0) {
		  factorial=factorial*numero2;
		  numero2--;
		}
		System.out.print("el factorial de " + numero + " es " +factorial);
	}
	
	
	
	}
}
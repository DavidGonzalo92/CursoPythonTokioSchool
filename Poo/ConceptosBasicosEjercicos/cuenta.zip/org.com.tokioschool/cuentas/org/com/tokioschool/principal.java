package org.com.tokioschool;
import java.util.Scanner;


public class principal {

	public static void main(String[] args) {
		 Scanner sc = new Scanner(System.in);
		 String nombre, numero;
		 
		 double Cantidad;

		 //se crea objeto cuenta1 sin par�metros

		 Cuenta cuenta1 = new Cuenta();

		 System.out.print("Nombre : ");
		 nombre = sc.next();
		 System.out.print("N�mero de cuenta : ");
		 numero = sc.next();
		 System.out.print("cantidad: ");
		 Cantidad = sc.nextDouble();

		 cuenta1.setNombre(nombre);
		 cuenta1.setNumeroCuenta(numero);
		 cuenta1.setCantidad(Cantidad);
		 
		 
		 Cuenta cuenta2 = new Cuenta();

		 System.out.print("Nombre : ");

		 nombre = sc.next();
		 System.out.print("N�mero de cuenta : ");
		 numero = sc.next();
		 System.out.print("cantidad: ");
		 Cantidad = sc.nextDouble();

		 cuenta2.setNombre(nombre);
		 cuenta2.setNumeroCuenta(numero);
		 cuenta2.setCantidad(Cantidad);
		 
		 
		 Cuenta.CompararCuentas(cuenta1,cuenta2);
			 
			 


	    }
	}
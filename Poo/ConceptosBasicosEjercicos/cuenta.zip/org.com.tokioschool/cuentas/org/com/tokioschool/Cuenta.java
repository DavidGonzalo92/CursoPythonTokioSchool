package org.com.tokioschool;

public class Cuenta {
	private String nombre;
    private String numeroCuenta;
    private double Cantidad;



    public Cuenta() {
    }


    public Cuenta(String nombre, String numeroCuenta,double Cantidad) {                         
        this.nombre = nombre;
        this.numeroCuenta = numeroCuenta;
        this.Cantidad = Cantidad;
    }


    public Cuenta(final Cuenta c) {
        nombre = c.nombre;
        numeroCuenta = c.numeroCuenta;
        Cantidad = c.Cantidad;
    }

    //getters y setters
    public void setNombre(String s) {
        nombre = s;
    }

    public void setNumeroCuenta(String s) {
        numeroCuenta = s;
    }

    public void setCantidad(double n) {
    	Cantidad = n;
    }


    public String getNombre() {
        return nombre;
    }

    public String getNumeroCuenta() {
        return numeroCuenta;
    }



    public double getCantidad() {
        return Cantidad;
    }

    public static void CompararCuentas(Cuenta c,Cuenta s)
    {
    	 if(c.getCantidad()>s.getCantidad()) {
			 System.out.print("cuenta 1 es mayor que cuenta 2");
		 }
		 if(c.getCantidad()==s.getCantidad()) {
			 System.out.print("cuentas iguales");
		 }
		 if(c.getCantidad()<s.getCantidad()) {
			 System.out.print("cuenta 2 es mayor que cuenta 1");
		 }

    }


}

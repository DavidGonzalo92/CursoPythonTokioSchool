package org.com.tokioschool;
import java.util.Scanner;


public class media_aritmetica {

	public static void main(String[] args) {
		int suma = 0, introducir,contador;
	    float media;
	      
	      
	    Scanner numero = new Scanner(System.in);
	     
	      
	    System.out.println("Ingresa el n�mero total de t�rminos que quieres que calcule la media");

	    contador = numero.nextInt();
	      
	    System.out.println("Por favor ingresa" + contador + " n�meros:");
	      
	    for(int x = 1; x<=contador ;x++){          
	          introducir = numero.nextInt();
	          suma = suma + introducir;
	    }
	      
	      media = suma / contador;
	      System.out.println("La media de " + contador + " los n�meros que ingresaste es " + media);
	    }
	}
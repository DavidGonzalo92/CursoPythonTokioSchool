from django.db import models
from django.contrib.auth.models import User



class persona(models.Model):
	usuario = models.OneToOneField(User, null=True, blank=True, on_delete=models.CASCADE)
	nombre = models.CharField(max_length=200, null=True)
	rol = models.CharField(max_length=200,null=True)

	def __str__(self):
		return self.nombre


class producto(models.Model):
    nombre = models.CharField(max_length=200)
    precio = models.FloatField()
    disponibles= models.IntegerField(default=0, null=True, blank=True)
    cantidad = models.IntegerField(default=0, null=True, blank=True)
    reponer = models.BooleanField(default=False)
    imagen = models.ImageField(null=True, blank=True)
 
    
    
    def __str__(self):
        return self.nombre
        
    
    
    def proporcion(self):
        return int(self.cantidad*(1/10))
                   
    
    def negativo(self):
        if self.disponibles>0:
            return self.disponibles
        else:
            return 1
    
    def pedir(self):
        if self.cantidad*1/10>=self.disponibles:
            return True
        else:
            return False
        
    
    @property
    def imageURL(self):
        try:
            url = self.imagen.url
        except:
            url = ''
        return url
    
class orden(models.Model):
    persona = models.ForeignKey(persona, on_delete=models.SET_NULL, null=True, blank=True)
    complete = models.BooleanField(default=False)
    transaction_id = models.CharField(max_length=100, null=True)
    
    def __str__(self):
        return str(self.id)
    
    @property
    def get_cart_total(self):
        ordenproductos = self.ordenproducto_set.all()
        total = sum([item.get_total for item in ordenproductos])
        return total
    
    @property
    def get_cart_items(self):
        ordenproductos = self.ordenproducto_set.all()
        total = sum([item.cantidad_producto for item in ordenproductos])
        return total

class ordenproducto(models.Model):
    producto = models.ForeignKey(producto, on_delete=models.SET_NULL, null=True)
    ordenacion = models.ForeignKey(orden, on_delete=models.SET_NULL, null=True)
    cantidad_producto = models.IntegerField(default=0, null=True, blank=True)
 
    @property
    def get_total(self):
        total = self.producto.precio * self.cantidad_producto
        return total
    




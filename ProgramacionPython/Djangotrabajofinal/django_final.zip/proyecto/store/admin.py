from django.contrib import admin
from .models import *

admin.site.register(persona)
admin.site.register(producto)
admin.site.register(orden)
admin.site.register(ordenproducto)

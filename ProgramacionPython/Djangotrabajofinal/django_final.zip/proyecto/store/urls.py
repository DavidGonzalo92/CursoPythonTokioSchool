from django.urls import path
from django.contrib import admin
from . import views
from django.http import HttpResponseRedirect
from django.urls import reverse
from django.contrib.auth import views as auth_views


urlpatterns = [
    

	path('', views.store, name="store"),
	path('cart/', views.cart, name="cart"),
	path('warehouse/', views.warehouse, name="warehouse"),
 	path('repositorie/', views.repositorie, name="repositorie"),
	path('update_item/', views.updateItem, name="update_item"),
	path('logout/', auth_views.LogoutView.as_view(), name='logout')


]



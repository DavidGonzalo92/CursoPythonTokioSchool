from django.shortcuts import render
from django.http import JsonResponse
import json
import datetime
from .models import * 
from django.shortcuts import redirect
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator

'''lo que cojen los template'''
@login_required
def store(request):
    
	if request.user.is_authenticated:
		persona = request.user.persona
		ordenes, created = orden.objects.get_or_create(persona=persona, complete=False)
		articulos = ordenes.ordenproducto_set.all()
		cartItems = ordenes.get_cart_items
	else:

		articulos = []
		ordenes = {'get_cart_total':0, 'get_cart_items':0}
		cartItems = ordenes['get_cart_items']

	productos = producto.objects.all()
	context = {'productos':productos, 'cartItems':cartItems}
	return render(request, 'store/store.html', context)


@login_required
def cart(request):
     if request.user.is_authenticated:
          persona = request.user.persona
          ordenes, created = orden.objects.get_or_create(persona=persona,complete=False)
          articulos = ordenes.ordenproducto_set.all()
          cartItems = ordenes.get_cart_items
         
     else:
          
          articulos = []
          ordenes = {'get_cart_total':0, 'get_cart_items':0}
          cartItems = ordenes['get_cart_items']
          
     context = {'articulos':articulos,'ordenes':ordenes, 'cartItems':cartItems}
     return render(request, 'store/cart.html', context)
@login_required
def repositorie(request):
     
     if request.user.persona.rol=='proveedor' or request.user.persona.rol=='admin':
          persona = request.user.persona
          ordenes, created = orden.objects.get_or_create(persona=persona,complete=False)
          cartItems = ordenes.get_cart_items
          productos = producto.objects.all()
          context = {'productos':productos,'cartItems':cartItems}
          return render(request, 'store/repositorie.html', context)
     else:
          return render(request, 'store/repositorie.html')

@login_required
def warehouse(request):
     if request.user.persona.rol=='admin':
          persona = request.user.persona
          ordenes, created = orden.objects.get_or_create(persona=persona,complete=False)
          cartItems = ordenes.get_cart_items
          productos = producto.objects.all()
          context = {'productos':productos,'cartItems':cartItems}
          return render(request, 'store/warehouse.html', context)
     else:
          return render(request, 'store/warehouse.html')
 
 
 
@login_required 
def updateItem(request):
     data = json.loads(request.body)
     productId = data['productId']
     action = data['action']
     print('Action:', action)
     print('Product:', productId)
    
     
     persona = request.user.persona
     productos = producto.objects.get(id=productId)

     
     
     
     
     ordenes, created = orden.objects.get_or_create(persona=persona,complete=False)
     articulos = ordenes.ordenproducto_set.all()

     ordenesarticulo, created = ordenproducto.objects.get_or_create(producto=productos,ordenacion=ordenes)
     
     almacenados=producto.objects.get(id=productId).disponibles
     
     if action == 'add':
          ordenesarticulo.cantidad_producto = (ordenesarticulo.cantidad_producto + 1)
     elif action == 'remove':
          ordenesarticulo.cantidad_producto = (ordenesarticulo.cantidad_producto - 1)
          
     
          
          
     ordenesarticulo.save()
     
     
     if action == 'delete':
          productos.disponibles-=ordenesarticulo.cantidad_producto
          print('almacenados',almacenados)
          ordenesarticulo.delete()
     productos.save()        
     
     if ordenesarticulo.cantidad_producto <= 0:
          
          
          ordenesarticulo.delete()
          
     return JsonResponse('Item was added', safe=False)






